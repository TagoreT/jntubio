#!/usr/bin/env bash

echo "listing available backups"
echo "-------------------------"
ls backups/
